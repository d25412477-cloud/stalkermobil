extends Node3D

var player: CharacterBody3D
var camera: Camera3D
var hud: CanvasLayer
var message: Label
var health := 100
var radiation := 0
var artifacts := 0
var quest_stage := 0
var look_touch := -1
var last_touch := Vector2.ZERO
var move_vector := Vector2.ZERO
var world_time := 0.0
var mutant: Node3D

func _ready():
    _make_world()
    _make_player()
    _make_hud()
    _say("КОРДОН. Найди торговца у бункера.")

func _make_world():
    var env := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_SKY
    e.sky = Sky.new()
    e.sky.sky_material = ProceduralSkyMaterial.new()
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.48, 0.52, 0.48)
    e.ambient_light_energy = 0.7
    env.environment = e
    add_child(env)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -25, 0)
    sun.light_energy = 1.1
    add_child(sun)
    _box("Земля", Vector3(0,-0.6,0), Vector3(90,1,90), Color(0.20,0.24,0.17))
    for i in range(28):
        var x = randf_range(-38,38)
        var z = randf_range(-38,38)
        if abs(x) < 8 and abs(z) < 8: continue
        _tree(Vector3(x,0,z))
    _box("Бункер", Vector3(0,1.6,-12), Vector3(10,4,7), Color(0.29,0.31,0.27))
    _box("Крыша", Vector3(0,3.8,-12), Vector3(11,0.5,8), Color(0.16,0.18,0.16))
    _box("Дверь", Vector3(0,1.1,-8.43), Vector3(2.1,2.2,0.15), Color(0.12,0.14,0.13))
    _box("Стол", Vector3(2,0.8,-11), Vector3(2.4,0.2,1.2), Color(0.24,0.15,0.08))
    _make_npc(Vector3(-2,0,-7), "Сидорович")
    _make_npc(Vector3(9,0,5), "Новичок")
    _make_artifact(Vector3(18,0.4,-4))
    _make_artifact(Vector3(-22,0.4,16))
    _make_mutant(Vector3(24,0,20))

func _box(n:String, pos:Vector3, size:Vector3, color:Color):
    var body = StaticBody3D.new()
    body.name = n
    body.position = pos
    var mesh = MeshInstance3D.new()
    var b = BoxMesh.new()
    b.size = size
    mesh.mesh = b
    var mat = StandardMaterial3D.new()
    mat.albedo_color = color
    mesh.material_override = mat
    body.add_child(mesh)
    var shape = CollisionShape3D.new()
    var s = BoxShape3D.new()
    s.size = size
    shape.shape = s
    body.add_child(shape)
    add_child(body)

func _tree(pos:Vector3):
    _box("Ствол", pos + Vector3(0,1.5,0), Vector3(0.55,3,0.55), Color(0.20,0.14,0.09))
    var crown = MeshInstance3D.new()
    var m = SphereMesh.new()
    m.radius = 1.7
    m.height = 3.2
    crown.mesh = m
    crown.position = pos + Vector3(0,3.7,0)
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color(0.12,0.20,0.13)
    crown.material_override = mat
    add_child(crown)

func _make_player():
    player = CharacterBody3D.new()
    player.position = Vector3(0,1,0)
    add_child(player)
    var col = CollisionShape3D.new()
    var capsule = CapsuleShape3D.new()
    capsule.radius = 0.38
    capsule.height = 1.8
    col.shape = capsule
    player.add_child(col)
    camera = Camera3D.new()
    camera.position = Vector3(0,0.55,0)
    camera.current = true
    player.add_child(camera)

func _make_npc(pos:Vector3, label:String):
    var n = Node3D.new()
    n.position = pos
    n.set_meta("npc_name", label)
    var body = MeshInstance3D.new()
    var mesh = CapsuleMesh.new()
    mesh.radius = 0.42
    mesh.height = 1.7
    body.mesh = mesh
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color(0.36,0.34,0.25)
    body.material_override = mat
    n.add_child(body)
    add_child(n)

func _make_artifact(pos:Vector3):
    var a = Area3D.new()
    a.position = pos
    a.set_meta("artifact", true)
    var mesh = MeshInstance3D.new()
    var sphere = SphereMesh.new()
    sphere.radius = 0.32
    mesh.mesh = sphere
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color(0.15,0.85,0.75)
    mat.emission_enabled = true
    mat.emission = Color(0.05,0.6,0.5)
    mesh.material_override = mat
    a.add_child(mesh)
    var col = CollisionShape3D.new()
    var sh = SphereShape3D.new()
    sh.radius = 1.2
    col.shape = sh
    a.add_child(col)
    a.body_entered.connect(func(b):
        if b == player and a.visible:
            artifacts += 1
            a.visible = false
            _say("Артефакт найден! Всего: %d" % artifacts)
            if artifacts >= 2:
                quest_stage = 2
                _say("Задание выполнено. Вернись к Сидоровичу.")
    )
    add_child(a)

func _make_mutant(pos:Vector3):
    mutant = Node3D.new()
    mutant.position = pos
    var mesh = MeshInstance3D.new()
    var sphere = SphereMesh.new()
    sphere.radius = 0.85
    mesh.mesh = sphere
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color(0.28,0.19,0.16)
    mesh.material_override = mat
    mutant.add_child(mesh)
    add_child(mutant)

func _make_hud():
    hud = CanvasLayer.new()
    add_child(hud)
    var panel = ColorRect.new()
    panel.color = Color(0,0,0,0.48)
    panel.position = Vector2(12,12)
    panel.size = Vector2(390,92)
    hud.add_child(panel)
    message = Label.new()
    message.position = Vector2(24,20)
    message.size = Vector2(360,78)
    message.add_theme_font_size_override("font_size", 20)
    hud.add_child(message)
    _add_button("ВПЕРЁД", Vector2(30,-150), "up")
    _add_button("НАЗАД", Vector2(30,-85), "down")
    _add_button("ВЛЕВО", Vector2(150,-85), "left")
    _add_button("ВПРАВО", Vector2(150,-150), "right")
    _add_button("ДЕЙСТВИЕ", Vector2(-180,-100), "action")

func _add_button(caption:String, offset:Vector2, action:String):
    var b = Button.new()
    b.text = caption
    b.custom_minimum_size = Vector2(112,58)
    b.anchor_left = 0.0 if offset.x >= 0 else 1.0
    b.anchor_right = 0.0 if offset.x >= 0 else 1.0
    b.anchor_top = 1.0
    b.anchor_bottom = 1.0
    b.position = offset
    hud.add_child(b)
    b.button_down.connect(func(): _button_action(action, true))
    b.button_up.connect(func(): _button_action(action, false))

func _button_action(action:String, pressed:bool):
    var v = 1.0 if pressed else 0.0
    match action:
        "up": move_vector.y = -v if pressed else 0.0
        "down": move_vector.y = v if pressed else 0.0
        "left": move_vector.x = -v if pressed else 0.0
        "right": move_vector.x = v if pressed else 0.0
        "action":
            if pressed: _interact()

func _unhandled_input(event):
    if event is InputEventScreenDrag:
        if event.position.x > get_viewport().size.x * 0.35:
            player.rotate_y(-event.relative.x * 0.004)
            camera.rotate_x(-event.relative.y * 0.004)
            camera.rotation.x = clamp(camera.rotation.x, -1.2, 1.2)

func _physics_process(delta):
    world_time += delta
    var dir = (player.transform.basis * Vector3(move_vector.x,0,move_vector.y)).normalized()
    player.velocity.x = dir.x * 5.0
    player.velocity.z = dir.z * 5.0
    player.velocity.y -= 20.0 * delta
    player.move_and_slide()
    if is_instance_valid(mutant):
        var d = player.global_position - mutant.global_position
        if d.length() < 18:
            mutant.position += d.normalized() * delta * 1.7
        if d.length() < 1.5:
            health = max(0, health - int(delta * 8))
    if int(world_time) % 12 == 0 and int(world_time) != 0:
        radiation = min(100, radiation + 1)
    message.text = "ЗОВ ЗОНЫ | Здоровье: %d | Радиация: %d%% | Артефакты: %d/2\\nЗадание: %s" % [health, radiation, artifacts, "найти 2 артефакта" if quest_stage < 2 else "вернуться к торговцу"]

func _interact():
    var nearest = null
    var best = 4.0
    for n in get_children():
        if n.has_meta("npc_name"):
            var d = player.global_position.distance_to(n.global_position)
            if d < best:
                nearest = n
                best = d
    if nearest:
        var nm = str(nearest.get_meta("npc_name"))
        if nm == "Сидорович":
            if quest_stage == 0:
                quest_stage = 1
                _say("Сидорович: Принеси мне два артефакта с Кордона.")
            elif quest_stage == 2:
                _say("Сидорович: Хорошая работа. Вот твоя награда!")
                health = min(100, health + 25)
                quest_stage = 3
            else:
                _say("Сидорович: Ищи артефакты за пределами бункера.")
        else:
            _say("Новичок: На Кордоне лучше быть осторожным.")
    elif quest_stage >= 2:
        _say("Найди Сидоровича у бункера.")
    else:
        _say("Осмотрись. Ищи светящиеся артефакты.")

func _say(t:String):
    if is_instance_valid(message):
        message.text = t
